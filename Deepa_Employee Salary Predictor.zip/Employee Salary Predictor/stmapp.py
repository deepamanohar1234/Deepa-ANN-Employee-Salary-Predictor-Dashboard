
import numpy as np # type: ignore
import pandas as pd # type: ignore
import plotly.express as px # type: ignore
import plotly.graph_objects as go # type: ignore
from sklearn.metrics import classification_report, confusion_matrix # type: ignore
from sklearn.model_selection import train_test_split # type: ignore
from sklearn.preprocessing import StandardScaler # type: ignore
import streamlit as st # type: ignore
from tensorflow.keras.layers import Dense, Dropout # type: ignore
from tensorflow.keras.models import Sequential #type: ignore

# --- Page Configuration ---
st.set_page_config(
    page_title="Salary & Career Analytics Dashboard", page_icon="💼", layout="wide"
)
@st.cache_data
def load_and_clean_data(file_path="Salary Data_2.csv"):
  df = pd.read_csv(file_path)
  cols_to_drop = [
      col for col in ["HQ Location", "HQ Location.1"] if col in df.columns
  ]
  df = df.drop(columns=cols_to_drop)
  df = df.dropna(
      subset=[
          "Age",
          "Gender",
          "Education Level",
          "Job Title",
          "Years of Experience",
          "Salary",
      ]
  )

  # Create 3 Salary Tiers (0 = Low, 1 = Medium, 2 = High)
  df["Salary_Tier"], bins = pd.qcut(
      df["Salary"], q=3, labels=[0, 1, 2], retbins=True
  )
  df["Salary_Tier"] = df["Salary_Tier"].astype(int)
  tier_names = {
      0: f"Low (< ${bins[1]:,.0f})",
      1: f"Medium (${bins[1]:,.0f} - ${bins[2]:,.0f})",
      2: f"High (> ${bins[2]:,.0f})",
  }
  df["Tier_Label"] = df["Salary_Tier"].map(tier_names)
  return df, tier_names


# --- Model Training (Cached so it runs only once) ---
@st.cache_resource
def train_ann_model(df):
  X_raw = df[[
      "Age",
      "Gender",
      "Education Level",
      "Job Title",
      "Years of Experience",
  ]]
  y = df["Salary_Tier"].values

  categorical_cols = ["Gender", "Education Level", "Job Title"]
  X_encoded = pd.get_dummies(X_raw, columns=categorical_cols, drop_first=True)
  feature_columns = X_encoded.columns.tolist()

  X_train, X_test, y_train, y_test = train_test_split(
      X_encoded, y, test_size=0.2, random_state=42, stratify=y
  )

  scaler = StandardScaler()
  X_train_scaled = scaler.fit_transform(X_train)
  X_test_scaled = scaler.transform(X_test)

  model = Sequential([ # type: ignore
      Dense(64, activation="relu", input_shape=(X_train_scaled.shape[1],)),
      Dropout(0.2),
      Dense(32, activation="relu"),
      Dense(3, activation="softmax"),
  ])

  model.compile(
      optimizer="adam",
      loss="sparse_categorical_crossentropy",
      metrics=["accuracy"],
  )
  history = model.fit(
      X_train_scaled,
      y_train,
      epochs=20,
      batch_size=32,
      validation_split=0.2,
      verbose=0,
  )

  test_loss, test_acc = model.evaluate(X_test_scaled, y_test, verbose=0)
  y_pred = np.argmax(model.predict(X_test_scaled, verbose=0), axis=1)

  return (
      model,
      scaler,
      feature_columns,
      history.history,
      test_acc,
      test_loss,
      y_test,
      y_pred,
  )


# Load Data & Train Model
try:
  df, tier_names = load_and_clean_data()
  (
      model,
      scaler,
      feature_columns,
      history,
      test_acc,
      test_loss,
      y_test,
      y_pred,
  ) = train_ann_model(df)
except Exception as e:
  st.error(
      "Error loading 'Salary Data_2.csv'. Please ensure the file is in the same"
      f" directory. Details: {e}"
  )
  st.stop()

  st.title("💼 Salary Predictor & Career Analytics Dashboard")
st.markdown(
    "Powered by an **Artificial Neural Network (ANN)** trained on employee"
    " compensation and demographic data."
)

# --- Navigation Tabs ---
tab1, tab2, tab3, tab4 = st.tabs([
    "🔮 Salary Prediction",
    "📊 Interactive Charts",
    "🚀 Career Analytics",
    "🧠 Model Information",
])

# ==========================================
# TAB 1: SALARY PREDICTION
# ==========================================
with tab1:
  st.header("Predict Employee Salary Tier")
  col1, col2 = st.columns([1, 1.2])

  with col1:
    st.subheader("Enter Profile Details")
    age = st.slider("Age", min_value=18, max_value=70, value=32)
    experience = st.slider(
        "Years of Experience", min_value=0, max_value=45, value=5
    )
    gender = st.selectbox("Gender", sorted(df["Gender"].unique()))
    education = st.selectbox(
        "Education Level", sorted(df["Education Level"].unique())
    )
    job_title = st.selectbox("Job Title", sorted(df["Job Title"].unique()))


    predict_btn = st.button(
        "Predict Salary Bracket", type="primary", use_container_width=True
    )

  with col2:
    st.subheader("Prediction Result")
    if predict_btn:
      # Create input dataframe matching training columns
      input_df = pd.DataFrame([{
          "Age": age,
          "Gender": gender,
          "Education Level": education,
          "Job Title": job_title,
          "Years of Experience": experience,
      }])
      input_encoded = pd.get_dummies(
          input_df,
          columns=["Gender", "Education Level", "Job Title"],
      )
      input_aligned = input_encoded.reindex(
          columns=feature_columns, fill_value=0
      )
      input_scaled = scaler.transform(input_aligned)

      # Predict probabilities
      probs = model.predict(input_scaled, verbose=0)[0]
      predicted_class = int(np.argmax(probs))

      st.success(f"### Predicted Tier: **{tier_names[predicted_class]}**")
      st.metric("Model Confidence", f"{probs[predicted_class] * 100:.1f}%")

      # Probability Breakdown Chart
      prob_df = pd.DataFrame({
          "Salary Tier": [tier_names[0], tier_names[1], tier_names[2]],
          "Probability (%)": probs * 100,
      })
      fig_prob = px.bar(
          prob_df,
          x="Probability (%)",
          y="Salary Tier",
          orientation="h",
          color="Salary Tier",
          text_auto=".1f",
          title="Prediction Confidence Across Tiers",
      )
      fig_prob.update_layout(showlegend=False, height=280)
      st.plotly_chart(fig_prob, use_container_width=True)
    else:
      st.info(
          "👈 Adjust the employee profile on the left and click **Predict"
          " Salary Bracket**."
      )

 #==========================================
# TAB 2: INTERACTIVE CHARTS
# ==========================================
with tab2:
  st.header("Interactive Compensation Explorer")

  # Filters
  f_col1, f_col2 = st.columns(2)
  selected_edu = f_col1.multiselect(
      "Filter by Education Level",
      options=df["Education Level"].unique(),
      default=df["Education Level"].unique(),
  )
  selected_gender = f_col2.multiselect(
      "Filter by Gender",
      options=df["Gender"].unique(),
      default=df["Gender"].unique(),
  )

  filtered_df = df[
      (df["Education Level"].isin(selected_edu))
      & (df["Gender"].isin(selected_gender))
  ]

  c1, c2 = st.columns(2)
  with c1:
    fig_scatter = px.scatter(
        filtered_df,
        x="Years of Experience",
        y="Salary",
        color="Education Level",
        size="Age",
        hover_data=["Job Title"],
        title="Salary vs. Years of Experience",
    )
    st.plotly_chart(fig_scatter, use_container_width=True)

  with c2:
    fig_box = px.box(
        filtered_df,
        x="Education Level",
        y="Salary",
        color="Gender",
        title="Salary Distribution by Education & Gender",
    )
    st.plotly_chart(fig_box, use_container_width=True)

  fig_hist = px.histogram(
      filtered_df,
      x="Salary",
      nbins=20,
      color="Tier_Label",
      title="Overall Salary Distribution by Tier",
      marginal="rug",
  )
  st.plotly_chart(fig_hist, use_container_width=True)

# ==========================================
# TAB 3: CAREER ANALYTICS
# ==========================================
with tab3:
  st.header("Career Progression & Role Insights")

  # Top KPI Metrics
  m1, m2, m3, m4 = st.columns(4)
  m1.metric("Average Salary", f"${df['Salary'].mean():,.0f}")
  m2.metric("Median Salary", f"${df['Salary'].median():,.0f}")
  m3.metric("Avg Experience", f"{df['Years of Experience'].mean():.1f} yrs")
  m4.metric("Total Profiles", f"{len(df):,}")

  st.divider()
  ca1, ca2 = st.columns(2)

  with ca1:
    top_roles = (
        df.groupby("Job Title")["Salary"]
        .mean()
        .sort_values(ascending=False)
        .head(10)
        .reset_index()
    )
    fig_roles = px.bar(
        top_roles,
        x="Salary",
        y="Job Title",
        orientation="h",
        color="Salary",
        color_continuous_scale="Viridis",
        title="Top 10 Highest-Paying Job Titles (Avg Salary)",
    )
    fig_roles.update_layout(yaxis={"categoryorder": "total ascending"})
    st.plotly_chart(fig_roles, use_container_width=True)

  with ca2:
    top_companies = (
        df.groupby("Education Level")["Salary"]
        .mean()
        .sort_values(ascending=False)
        .head(10)
        .reset_index()
    )
    fig_comp = px.bar(
        top_companies,
        x="Education Level",
        y="Salary",
        color="Education Level",
        category_orders={"EducationLevel": ["Bachelor's", "Master's", "PhD"]},
        color_continuous_scale="Blues",
        title="Education Level Vs Salary Prediction"
    )
    fig_comp.update_layout(yaxis={"categoryorder": "total ascending"})
    st.plotly_chart(fig_comp, use_container_width=True)

  # Experience Bracket Progression
  df["Exp_Group"] = pd.cut(
      df["Years of Experience"],
      bins=[-1, 2, 5, 10, 15, 50],
      labels=["0-2 yrs", "3-5 yrs", "6-10 yrs", "11-15 yrs", "15+ yrs"],
  )
  exp_prog = (
      df.groupby("Exp_Group", observed=False)["Salary"].mean().reset_index()
  )
  fig_exp = px.line(
      exp_prog,
      x="Exp_Group",
      y="Salary",
      markers=True,
      title="Average Career Salary Growth by Experience Stage",
  )
  st.plotly_chart(fig_exp, use_container_width=True)

  # ==========================================
# TAB 4: MODEL INFORMATION
# ==========================================
with tab4:
  st.header("Artificial Neural Network (ANN) Architecture & Metrics")

  # 1. Top Model KPIs
  k1, k2, k3, k4 = st.columns(4)
  k1.metric("Test Accuracy", f"{test_acc * 100:.2f}%")
  k2.metric("Test Loss", f"{test_loss:.4f}")
  k3.metric("Input Features", f"{len(feature_columns)}")
  k4.metric("Total Parameters", f"{model.count_params():,}")

  st.divider()

  # 2. Training & Validation Learning Curves
  mc1, mc2 = st.columns(2)
  epochs_range = list(range(1, len(history["accuracy"]) + 1))

  with mc1:
    fig_acc = go.Figure()
    fig_acc.add_trace(
        go.Scatter(
            x=epochs_range,
            y=history["accuracy"],
            mode="lines+markers",
            name="Train Accuracy",
        )
    )
    fig_acc.add_trace(
        go.Scatter(
            x=epochs_range,
            y=history["val_accuracy"],
            mode="lines+markers",
            name="Validation Accuracy",
        )
    )
    fig_acc.update_layout(
        title="Training vs. Validation Accuracy",
        xaxis_title="Epoch",
        yaxis_title="Accuracy",
    )
    st.plotly_chart(fig_acc, use_container_width=True)

  with mc2:
    fig_loss = go.Figure()
    fig_loss.add_trace(
        go.Scatter(
            x=epochs_range,
            y=history["loss"],
            mode="lines+markers",
            name="Train Loss",
        )
    )
    fig_loss.add_trace(
        go.Scatter(
            x=epochs_range,
            y=history["val_loss"],
            mode="lines+markers",
            name="Validation Loss",
        )
    )
    fig_loss.update_layout(
        title="Training vs. Validation Loss",
        xaxis_title="Epoch",
        yaxis_title="Loss",
    )
    st.plotly_chart(fig_loss, use_container_width=True)

  st.divider()

  # 3. Confusion Matrix & Precision/Recall Report
  cm_col, rep_col = st.columns([1.1, 1.2])

  with cm_col:
    cm = confusion_matrix(y_test, y_pred)
    labels = ["Low", "Medium", "High"]
    fig_cm = px.imshow(
        cm,
        text_auto=True,
        x=labels,
        y=labels,
        color_continuous_scale="Teal",
        title="Test Set Confusion Matrix",
        labels=dict(x="Predicted Tier", y="Actual Tier"),
    )
    st.plotly_chart(fig_cm, use_container_width=True)

  with rep_col:
    st.subheader("Classification Performance Report")
    report_dict = classification_report(
        y_test,
        y_pred,
        target_names=["Low Tier", "Medium Tier", "High Tier"],
        output_dict=True,
    )
    report_df = pd.DataFrame(report_dict).transpose().round(3)
    st.dataframe(report_df, use_container_width=True)
    st.caption(
        "**Precision:** Accuracy of positive predictions | **Recall:** Ability"
        " to find all positives | **F1-Score:** Balance of both"
    )

  st.divider()

  # 4. Network Architecture Table & Export Option
  arch_col, param_col = st.columns([1.3, 1])

  with arch_col:
    st.subheader("Layer-by-Layer Network Summary")
    layer_data = []
    for layer in model.layers:
      layer_data.append({
          "Layer Name": layer.name,
          "Type": layer.__class__.__name__,
          "Output Shape": str(layer.output.shape),
          "Activation": (
              getattr(layer, "activation", None).__name__
              if hasattr(layer, "activation")
              else "None"
          ),
          "Parameters": f"{layer.count_params():,}",
      })
    st.table(pd.DataFrame(layer_data))

  with param_col:
    st.subheader("Hyperparameters & Pipeline")
    st.markdown("""
        * **Preprocessing:** `StandardScaler` (numerical) + One-Hot Encoding (categorical)
        * **Optimizer:** Adam (`learning_rate=0.001`)
        * **Loss Function:** `sparse_categorical_crossentropy`
        * **Batch Size:** 32 | **Epochs:** 20
        * **Validation Split:** 20% of training set
        """)

    # Save & Download Trained Model Button
    model.save("trained_salary_ann.keras")
    with open("trained_salary_ann.keras", "rb") as f:
      st.download_button(
          label="⬇️ Download Trained Model (.keras)",
          data=f,
          file_name="trained_salary_ann.keras",
          mime="application/octet-stream",
          use_container_width=True,
      )


